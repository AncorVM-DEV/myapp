import 'package:flutter/material.dart';
import 'package:myapp/main.dart' show supabase;
import 'package:myapp/widgets/app_colores.dart';

// ── SECCIÓN DE SUBTAREAS CONECTADA A SUPABASE ─────────────────────────────────
// Este widget sustituye la maqueta visual que había en dialogo_info_tarea.dart.
// Lista las subtareas de la tabla 'subtasks' en tiempo real y permite
// marcar cada una como completada con un simple clic.
// Respeta el diseño oscuro de la app y la paleta de colores de AppColores.
class SeccionSubtareas extends StatefulWidget {
  // El ID de la tarea padre para filtrar sus subtareas en Supabase
  final String taskId;

  const SeccionSubtareas({super.key, required this.taskId});

  @override
  State<SeccionSubtareas> createState() => _SeccionSubtareasState();
}

class _SeccionSubtareasState extends State<SeccionSubtareas> {
  // Controlador del campo de texto para añadir una nueva subtarea
  final _nuevaSubtareaCont = TextEditingController();

  // Si está en true mostramos el campo de texto para añadir
  bool _mostrandoInput = false;

  // Para evitar que el usuario pulse "Añadir" dos veces seguidas
  bool _guardando = false;

  @override
  void dispose() {
    _nuevaSubtareaCont.dispose();
    super.dispose();
  }

  // Cambia el estado is_completed de una subtarea al contrario de lo que tiene
  Future<void> _toggleSubtarea(String subtareaId, bool completadaActual) async {
    try {
      await supabase
          .from('subtasks')
          .update({'is_completed': !completadaActual})
          .eq('id', subtareaId);
    } catch (e) {
      debugPrint('Error al cambiar subtarea: $e');
    }
  }

  // ── NUEVO: elimina la subtarea de Supabase definitivamente ────────────────
  // El stream en tiempo real actualizará la lista automáticamente tras el borrado,
  // así que no hay que hacer nada más después del delete.
  Future<void> _eliminarSubtarea(String subtareaId) async {
    try {
      await supabase.from('subtasks').delete().eq('id', subtareaId);
    } catch (e) {
      debugPrint('Error al eliminar subtarea: $e');
    }
  }

  // Guarda una nueva subtarea en Supabase con el título que escribió el usuario
  Future<void> _guardarNuevaSubtarea() async {
    final titulo = _nuevaSubtareaCont.text.trim();
    if (titulo.isEmpty) return;

    setState(() => _guardando = true);

    try {
      await supabase.from('subtasks').insert({
        'task_id': widget.taskId,
        'title': titulo,
        'is_completed': false,
      });

      // Limpiamos el campo y ocultamos el input tras guardar
      _nuevaSubtareaCont.clear();
      if (mounted) {
        setState(() {
          _mostrandoInput = false;
          _guardando = false;
        });
      }
    } catch (e) {
      debugPrint('Error al crear subtarea: $e');
      if (mounted) setState(() => _guardando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      // Stream en tiempo real de las subtareas de esta tarea concreta
      stream: supabase
          .from('subtasks')
          .stream(primaryKey: ['id'])
          .eq('task_id', widget.taskId),
      builder: (context, snapshot) {
        // Lista de subtareas (puede estar vacía pero nunca null si no hay error)
        final subtareas = snapshot.data ?? [];

        // Contamos cuántas están completadas para mostrar el progreso
        final completadas = subtareas.where((s) => s['is_completed'] == true).length;
        final total = subtareas.length;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Indicador de progreso (solo si hay subtareas) ──────────────
            if (total > 0) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '$completadas / $total completadas',
                    style: const TextStyle(color: AppColores.textMuted, fontSize: 11),
                  ),
                  Text(
                    '${(completadas / total * 100).round()}%',
                    style: const TextStyle(
                      color: AppColores.orangeLight,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              // Barra de progreso visual
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: completadas / total,
                  backgroundColor: AppColores.borderColor,
                  valueColor: const AlwaysStoppedAnimation(AppColores.orangePrimary),
                  minHeight: 4,
                ),
              ),
              const SizedBox(height: 10),
            ],

            // ── Estado de carga ────────────────────────────────────────────
            if (snapshot.connectionState == ConnectionState.waiting && total == 0)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: AppColores.orangePrimary,
                      strokeWidth: 2,
                    ),
                  ),
                ),
              )

            // ── Lista de subtareas ─────────────────────────────────────────
            else if (total == 0)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E2030),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColores.borderColor.withOpacity(0.5)),
                ),
                child: const Text(
                  'Todavía no hay subtareas',
                  style: TextStyle(color: AppColores.textMuted, fontSize: 12),
                ),
              )
            else
              // Cada subtarea es un tile con checkbox y texto
              Column(
                children: subtareas.map((subtarea) {
                  final estaCompletada = subtarea['is_completed'] as bool? ?? false;
                  final subtareaId = subtarea['id'] as String;

                  return MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: InkWell(
                      onTap: () => _toggleSubtarea(subtareaId, estaCompletada),
                      borderRadius: BorderRadius.circular(8),
                      child: Padding(
                        // Padding generoso para garantizar área de toque 48x48
                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                        child: Row(
                          children: [
                            // Checkbox visual animado
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: estaCompletada
                                    ? AppColores.orangePrimary
                                    : Colors.transparent,
                                border: Border.all(
                                  color: estaCompletada
                                      ? AppColores.orangePrimary
                                      : AppColores.borderColor,
                                  width: 1.5,
                                ),
                              ),
                              child: estaCompletada
                                  ? const Icon(Icons.check, color: Colors.white, size: 12)
                                  : null,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                subtarea['title'] as String? ?? '',
                                style: TextStyle(
                                  color: estaCompletada
                                      // Las completadas se muestran más apagadas y tachadas
                                      ? AppColores.textMuted
                                      : Colors.white,
                                  fontSize: 13,
                                  // Tachamos el texto al completarse
                                  decoration: estaCompletada
                                      ? TextDecoration.lineThrough
                                      : TextDecoration.none,
                                  decorationColor: AppColores.textMuted,
                                ),
                              ),
                            ),
                            // ── NUEVO: botón de borrar subtarea ───────────────
                            // Aparece siempre a la derecha de cada fila.
                            // Al pulsar, elimina la subtarea de Supabase y el
                            // stream actualiza la lista solo, sin más código.
                            // Usamos GestureDetector en lugar de IconButton para
                            // evitar que el tap se propague al InkWell del toggle.
                            MouseRegion(
                              cursor: SystemMouseCursors.click,
                              child: GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => _eliminarSubtarea(subtareaId),
                                child: const Padding(
                                  // Padding de 10 para garantizar área de toque cómoda
                                  padding: EdgeInsets.all(10),
                                  child: Icon(
                                    Icons.delete_outline,
                                    size: 16,
                                    // Color muted para que no distraiga, pero visible
                                    color: AppColores.textMuted,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),

            const SizedBox(height: 8),

            // ── Input para nueva subtarea ──────────────────────────────────
            // Se muestra al pulsar "Añadir subtarea" y se oculta al guardar
            if (_mostrandoInput) ...[
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _nuevaSubtareaCont,
                      autofocus: true,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _guardarNuevaSubtarea(),
                      decoration: InputDecoration(
                        hintText: 'Nombre de la subtarea...',
                        hintStyle: const TextStyle(
                          color: AppColores.textMuted,
                          fontSize: 13,
                        ),
                        filled: true,
                        fillColor: const Color(0xFF1E2030),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: const BorderSide(color: AppColores.borderColor),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: const BorderSide(color: AppColores.borderColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: const BorderSide(
                            color: AppColores.orangePrimary,
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  // Botón de confirmar
                  MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: IconButton(
                      icon: _guardando
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                color: AppColores.orangePrimary,
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(
                              Icons.check_rounded,
                              color: AppColores.orangePrimary,
                            ),
                      tooltip: 'Guardar subtarea',
                      // Área mínima de 48x48
                      padding: const EdgeInsets.all(12),
                      onPressed: _guardando ? null : _guardarNuevaSubtarea,
                    ),
                  ),
                  // Botón de cancelar el input
                  MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: IconButton(
                      icon: const Icon(Icons.close_rounded, color: AppColores.textMuted),
                      tooltip: 'Cancelar',
                      padding: const EdgeInsets.all(12),
                      onPressed: () {
                        setState(() {
                          _mostrandoInput = false;
                          _nuevaSubtareaCont.clear();
                        });
                      },
                    ),
                  ),
                ],
              ),
            ] else
              // Botón para mostrar el input de nueva subtarea
              TextButton.icon(
                onPressed: () => setState(() => _mostrandoInput = true),
                icon: const Icon(Icons.add_rounded, size: 16),
                label: const Text('Añadir subtarea'),
                style: TextButton.styleFrom(
                  foregroundColor: AppColores.orangeLight,
                  padding: EdgeInsets.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ),
          ],
        );
      },
    );
  }
}
